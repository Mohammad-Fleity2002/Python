window.onload = start();
function start() {
  // register.addEventListener(checkInput());
  // var register = document.getElementById("register");
  // var test = document.getElementById("test");
  var username = document.getElementById("username");
  var invalidUsername = document.getElementById("invalidUsername");
  var validUsername = document.getElementById("validUsername");
  var email = document.getElementById("email");
  var validEmail = document.getElementById("validEmail");
  var invalidEmail = document.getElementById("invalidEmail");
  var password = document.getElementById("password");
  var invalidPassword = document.getElementById("invalidPassword");
  var validPassword = document.getElementById("validPassword");
  var confirmPassword = document.getElementById("confirmPassword");
  var invalidConfirmPassword = document.getElementById(
    "invalidConfirmPassword"
  );
  var validConfirmPassword = document.getElementById("validConfirmPassword");
  var confirmData = document.getElementById("confirmData");
  var invalidConfirmData = document.getElementById("invalidConfirmData");
  var xUsername = document.getElementById("xUsername");
  var xEmail = document.getElementById("xEmail");
  var xPassword = document.getElementById("xPassword");
  var xConfirm = document.getElementById("xConfirm");
  var tUsername = document.getElementById("tUsername");
  var tEmail = document.getElementById("xEmail");
  var tPassword = document.getElementById("xPassword");
  var tConfirm = document.getElementById("xConfirm");
}
function checkInput() {
  if (username.value == "") {
    invalidUsername.classList.add("d-block");
    validUsername.classList = "valid-feedback";
    xUsername.classList = "input-group-text bg-light text-danger";
    tUsername.classList.add("d-none");
  } else {
    invalidUsername.classList = "invalid-feedback";
    validUsername.classList.add("d-block");
    xUsername.classList.add("d-none");
    tUsername.classList = "input-group-text bg-light text-success fw-bold";
  }
  if (email.value == "") {
    invalidEmail.classList.add("d-block");
    validEmail.classList = "valid-feedback";
    tEmail.classList.add("d-none");
    xEmail.classList = "input-group-text bg-light text-danger";
  } else {
    invalidEmail.classList = "invalid-feedback";
    validEmail.classList.add("d-block");
    xEmail.classList.add("d-none");
    tEmail.classList = "input-group-text bg-light text-success fw-bold";
  }
  if (password.value == "") {
    invalidPassword.classList.add("d-block");
    validPassword.classList = "valid-feedback"; //the user may delete the input
    xPassword.classList = "input-group-text bg-light text-danger";
    tPassword.classList.add("d-none");
  } else {
    validPassword.classList.add("d-block");
    invalidPassword.classList = "invalid-feedback";
    xPassword.classList.add("d-none");
    tPassword.classList = "input-group-text bg-light text-success fw-bold";
  }
  if (confirmPassword.value != "") {
    if (confirmPassword.value == password.value) {
      validConfirmPassword.classList.add("d-block");
      invalidConfirmPassword.classList = "invalid-feedback";
      xConfirm.classList.add("d-none");
      tConfirm.classList = "input-group-text bg-light text-success fw-bold";
    } else {
      invalidConfirmPassword.classList.add("d-block");
      validConfirmPassword.classList = "valid-feedback";
      xConfirm.classList = "input-group-text bg-light text-danger";
      tConfirm.classList.add("d-none");
    }
  }
  if (!confirmData.checked) {
    invalidConfirmData.classList.add("d-block");
  } else {
    invalidConfirmData.classList = "invalid-feedback";
  }
}
