window.onload = function start() {
  enableClosing();
  enableChecking();
  let add = document.getElementById("pencil");
  add.addEventListener("click", addTask);
};
function addTask() {
  let task = document.getElementById("inputTask");
  let newTask = task.value;
  if (newTask != "") {
    let xclose = document.createElement("button");
    let li = document.createElement("li");
    xclose.innerText = "x";
    xclose.classList.add("close");
    xclose.addEventListener("click", function () {
      this.parentElement.style.display = "none";
    });
    li.addEventListener("click", function () {
      if (this.classList == "border twhite checked") {
        /* to uncheck*/
        this.classList = "border twhite";
      } else {
        /*to check*/
        this.classList.add("checked");
      }
    });
    let list = document.getElementById("tasks");
    li.innerText = newTask;
    li.appendChild(xclose);
    li.classList.add("border");
    li.classList.add("twhite");
    list.appendChild(li);
    task.value = "";
  } else {
    alert("You must enter a task to add");
  }
}
function enableClosing() {
  // to add event listener to task already created
  //   alert("test");
  //   console.log(tobeClosed);
  let tobeClosed = document.getElementsByClassName("close");
  for (let i = 0; i < tobeClosed.length; i++) {
    tobeClosed[i].addEventListener("click", function () {
      this.parentElement.style.display = "none";
    });
  }
}
function enableChecking() {
  let tobeChecked = document.getElementsByTagName("li");
  // console.log(tobeChecked);
  for (let i = 0; i < tobeChecked.length; i++) {
    tobeChecked[i].addEventListener("click", function () {
      if (this.classList == "border twhite checked") {
        /* to uncheck*/
        this.classList = "border twhite";
      } else {
        /*to check*/
        this.classList.add("checked");
      }
    });
  }
}
